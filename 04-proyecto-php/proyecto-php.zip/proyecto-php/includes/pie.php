
			<div class="clearfix"></div>
		</div> <!-- fin contenedor -->

		<!-- PIE DE PÁGINA -->
		<footer id="pie">
			<p>Desarrollado por Víctor Robles &copy; 2018</p>
		</footer>
		
	</body>
</html>
