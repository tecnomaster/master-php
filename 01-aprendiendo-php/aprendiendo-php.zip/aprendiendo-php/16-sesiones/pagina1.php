<?php

session_start();

// echo $variable_normal;

echo $_SESSION['variable_persistente'];