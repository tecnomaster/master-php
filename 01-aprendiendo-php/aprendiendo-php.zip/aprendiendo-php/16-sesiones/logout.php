<?php

session_start();

// Cierro la sesión
session_destroy();
