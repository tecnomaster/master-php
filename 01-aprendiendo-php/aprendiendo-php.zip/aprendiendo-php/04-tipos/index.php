<?php

/*
 TIPOS DE DATOS:
 Entero (int / integer) = 99
 Coma flotante / decimales (float / double) = 3.45
 Cadenas (string) = "Hola yo soy un string"
 Boleano (bool) = true false
 null
 Array (Coleccion de datos)
 Objetos
 */

$numero_hola = 100;
$decimal = 27.9;
$texto = "Soy un texto $numero_hola";
$verdadero = false;
$nula = null;

echo $texto;

//echo gettype($nula);

// Debugear
$mi_nombre[] = "Víctor Robles WEB";
$mi_nombre[] = "Víctor Robles WEB";

// var_dump($mi_nombre);