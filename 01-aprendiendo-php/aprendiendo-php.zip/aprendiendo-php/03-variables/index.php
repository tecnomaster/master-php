<?php

// Una variable es un contenedor de información, puedo guardar cualquier dato dentro de ella
$mi_primera_variable = "Hola Mundo desde una variable";
$numero = 44;
$verdadero = true;

$numero = 77;

echo '<h1>'.$mi_primera_variable.'</h1>';
echo $numero."<br>";

$numero = 120;

echo $numero;

?>