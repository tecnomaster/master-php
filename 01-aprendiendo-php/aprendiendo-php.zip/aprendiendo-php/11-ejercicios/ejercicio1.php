<?php

/* 
 Ejercicio 1. Crear dos variables "pais" y "continente" y mostrar su valor por pantalla(imprimir)
 Poner en un comentario que tipo de dato tienen.
 */

$pais = "España";  // string
$continente = "Europa"; // string

echo "<h1>$pais - $continente</h1>";