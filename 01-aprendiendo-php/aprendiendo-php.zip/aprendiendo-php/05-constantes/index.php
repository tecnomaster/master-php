<?php

// Constantes
// Es un contenedor de información que no puede variar

define('nombre', 'Víctor Robles');
define('web', 'victorroblesweb.es');

echo '<h1>'.nombre.'</h1>';
echo '<h1>'.web.'</h1>';

// Variable
$web = "victorroblesweb.es/academy";
$web = "victorroblesweb.es/cursos";
echo '<h1>'.$web.'</h1>';

// Constantes predefinidas

echo PHP_OS;









