<?php
include 'includes/cabecera.php';
?>
	
		<!--Contenido-->
		<div>
			<h2>Esta es la pagina de contacto</h2>
			<p>Texto de prueba de la página de contacto</p>
		</div>
		
<?php include 'includes/footer.php'; ?>