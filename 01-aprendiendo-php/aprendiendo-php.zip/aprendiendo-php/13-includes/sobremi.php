<?php
include 'includes/cabecera.php';
?>
		<!--Contenido-->
		<div>
			<h2>Esta es la pagina de Sobre mi</h2>
			<p>Texto de prueba de la página de sobre mi</p>
		</div>
		
<?php include 'includes/footer.php'; ?>