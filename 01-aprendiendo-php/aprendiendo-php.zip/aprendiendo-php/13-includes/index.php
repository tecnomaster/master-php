<?php require_once 'includes/cabecera.php'; ?>

		<!--Contenido-->
		<div>
			<h2>Esta es la pagina de inicio</h2>
			<p>Texto de prueba de la página de inicio</p>
		</div>
		<?php var_dump($nombre); ?>

<?php require_once 'includes/footer.php'; ?>