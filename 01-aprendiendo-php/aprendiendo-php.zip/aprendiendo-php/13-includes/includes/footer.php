		<!--Pie de pagina-->
		<footer>
			<hr/>
			Todos los reservados &copy; <?=$nombre?> <?=date('Y')?>
		</footer>
		
	</body>
</html>
