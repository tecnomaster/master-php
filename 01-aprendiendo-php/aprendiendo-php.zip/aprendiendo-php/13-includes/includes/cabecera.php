<!DOCTYPE HTML>
<html lang="es">
	<head>
		<meta charset="utf-8" />
		<title>Includes en PHP 7</title>
	</head>
	<body>
		<?php
			$nombre = "Juan Francisco";
		?>
		<!--Cabecera-->
		<div class="cabecera">
			<h1>Includes en PHP 7</h1>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="sobremi.php">Sobre mi</a></li>
				<li><a href="contacto.php">Contacto</a></li>
				<li><a href="https://google.es">Google</a></li>
			</ul>
			<hr/>
		</div>
