<tr>
	<?php foreach($categorias as $categoria): ?>
		<th><?=$categoria?></th>
	<?php endforeach; ?>
</tr>