<tr>
	<td><?=$tabla['ACCION'][2]?></td>
	<td><?=$tabla['AVENTURA'][2]?></td>
	<td><?=$tabla['DEPORTES'][2]?></td>
</tr>
