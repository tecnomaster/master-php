<tr>
	<td><?=$tabla['ACCION'][0]?></td>
	<td><?=$tabla['AVENTURA'][0]?></td>
	<td><?=$tabla['DEPORTES'][0]?></td>
</tr>
