<tr>
	<td><?=$tabla['ACCION'][1]?></td>
	<td><?=$tabla['AVENTURA'][1]?></td>
	<td><?=$tabla['DEPORTES'][1]?></td>
</tr>
