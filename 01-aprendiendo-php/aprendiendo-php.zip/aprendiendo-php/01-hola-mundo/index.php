<h1>Hola Mundo, esto es HTML</h1>

<?php

  echo '<h2>Hola Mundo con PHP 7</h2>';

?>